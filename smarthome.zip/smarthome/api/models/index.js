const Device = require('./Device');

module.exports = {
  Device,
};
