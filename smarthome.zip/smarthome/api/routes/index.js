const devices = require('./devices');

module.exports = {
  devices,
};
