# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [0.1.6](https://github.com/zircleui/tutorial/compare/v0.1.5...v0.1.6) (2019-05-02)



<a name="0.1.5"></a>
## [0.1.5](https://github.com/zircleui/tutorial/compare/v0.1.4...v0.1.5) (2019-04-22)



<a name="0.1.4"></a>
## [0.1.4](https://github.com/zircleui/tutorial/compare/v0.1.3...v0.1.4) (2019-01-06)



<a name="0.1.3"></a>
## [0.1.3](https://github.com/zircleui/tutorial/compare/v0.1.2...v0.1.3) (2018-11-25)


### Bug Fixes

* 🐛 home name ([071b762](https://github.com/zircleui/tutorial/commit/071b762)), closes [#1](https://github.com/zircleui/tutorial/issues/1)



<a name="0.1.2"></a>
## [0.1.2](https://github.com/zircleui/tutorial/compare/v0.1.1...v0.1.2) (2018-11-19)



<a name="0.1.1"></a>
## 0.1.1 (2018-08-17)
